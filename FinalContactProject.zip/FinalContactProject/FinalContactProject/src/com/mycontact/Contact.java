package com.mycontact;

public class Contact {

	/**
	 * @param contactNumber
	 * @param contactName
	 */
	public Contact(String contactName, String contactNumber) {
		super();
		this.contactNumber = contactNumber;
		this.contactName = contactName;
	}
	
	private String contactNumber;
	private String contactName;	
	
	  public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getContactName() {
		return contactName;
	}
	public void setContactName(String contactName) {
		this.contactName = contactName;
	}
	
	
}
