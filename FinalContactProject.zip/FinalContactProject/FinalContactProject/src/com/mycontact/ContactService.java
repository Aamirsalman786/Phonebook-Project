package com.mycontact;

import java.util.List;

import javax.websocket.server.PathParam;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;



@Path("/contacts")
public class ContactService {
	ContactDAO cd =new ContactDAO();
	@GET
    @Produces(MediaType.APPLICATION_JSON  )
    public List<Contact> getContacts() {
       
        return ContactDAO.getAllContacts();
    }
 
    // URI:
    // /contextPath/servletPath/employees/{empNo}
    @GET
    @Path("/{contactName}")
    @Produces( MediaType.APPLICATION_JSON)
    public Contact getContact(@PathParam("contactName") String contactName) {
        return ContactDAO.getContact(contactName);
    }
 
    // URI:
    // /contextPath/servletPath/employees
    @POST
    @Produces( MediaType.APPLICATION_JSON)
    public Contact addContact(Contact con) {
        return ContactDAO.addContact(con);
    }
    // URI:
    // /contextPath/servletPath/employees
    @PUT
    @Produces(MediaType.APPLICATION_JSON)
    public Contact updateContact(Contact con) {
        return ContactDAO.updateContact(con);
    }
 
    @DELETE
    @Path("/{contactName}")
    @Produces(MediaType.APPLICATION_JSON)
    public void deleteContact(@PathParam("contactName") String contactName) {
    	ContactDAO.deleteContact(contactName);
    }
}
