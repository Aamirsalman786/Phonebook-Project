package com.mycontact;




public class Contact {


	public Contact(String contactName, String contactNumber) {
		super();
		this.contactNumber = contactNumber;
		this.contactName = contactName;
	}
	
	public Contact() {	  //Default Constructor for Postman post,put command
	}
	
	 String contactNumber;
	 String contactName;	
	
	  public String getContactNumber() {
		return contactNumber;
	}
	
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getContactName() {
		return contactName;
	}
	
	public void setContactName(String contactName) {
		this.contactName = contactName;
	}
	
	
}