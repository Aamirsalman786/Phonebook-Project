export class phonebook{
    contactName: string;
    contactNumber: string;
}