import { Component, OnInit } from '@angular/core';
import { ContactService } from '../contact.service';

@Component({
  selector: 'app-view-all-contacts',
  templateUrl: './view-all-contacts.component.html',
  styleUrls: ['./view-all-contacts.component.css']
})
export class ViewAllContactsComponent  {

  data: any;

  constructor(private service: ContactService) { }

  viewAllContacts() {
    this.service.fetchContacts().subscribe(data =>{
      this.data =data;  
    })
  }
  ngAfterViewInit(){
    this.viewAllContacts();

  }  
}
