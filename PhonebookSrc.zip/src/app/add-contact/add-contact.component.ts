import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { phonebook } from 'src/Phonebook';
import { ContactService } from '../contact.service';

@Component({
  selector: 'app-add-contact',
  templateUrl: './add-contact.component.html',
  styleUrls: ['./add-contact.component.css']
})

export class AddContactComponent  implements OnInit{
  cont: phonebook = new phonebook();
  constructor(private cs: ContactService, private http: HttpClient){
    this.cont.contactName = '';
    this.cont.contactNumber='';
   }
  
  ngOnInit(): void {}

  addContact(){
    alert(JSON.stringify(this.cont));
    this.cs.addContact(this.cont).subscribe(data =>{
      alert(JSON.stringify(data));
      alert(data);
      console.log(data)
    })
  }

}
