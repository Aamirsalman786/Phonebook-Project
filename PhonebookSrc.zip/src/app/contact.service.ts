import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { phonebook } from 'src/Phonebook';

@Injectable({
  providedIn: 'root'
})
export class ContactService {

  constructor(private http: HttpClient) { }
  fetchContacts( ) { let url = 'http://localhost:8085/FinalContactProject/rest/contacts';
  return this.http.get(url);
}
  fetchContact (contactName: string) {
    let url ='http://localhost:8085/FinalContactProject/rest/contacts'+contactName;
    return this.http.get(url);
  }
  addContact(cont:phonebook) {
    let url ='http://localhost:8085/FinalContactProject/rest/contacts';
    return this.http.post(url,cont);
  }
  editContact(cont:phonebook) {
    let url ='http://localhost:8085/FinalContactProject/rest/contacts';
  return this.http.put(url,cont);
  }
  deleteContact(cont:phonebook) {
    let url ='http://localhost:8085/FinalContactProject/rest/contacts';
  return this.http.delete(url);
  }
  
  }

