import { Component, OnInit } from '@angular/core';
import { phonebook } from 'src/Phonebook';
import { ContactService } from '../contact.service';

@Component({
  selector: 'app-delete-contact',
  templateUrl: './delete-contact.component.html',
  styleUrls: ['./delete-contact.component.css']
})
export class DeleteContactComponent implements OnInit {

  cont:phonebook =new phonebook();
  constructor(private service: ContactService) {
    this.cont.contactName='';
    // this.cont.contactNumber='';
   }

  ngOnInit(): void {
  }
  deleteContact(){
    this.service.deleteContact(this.cont).subscribe(data =>{

    })
  }
}
