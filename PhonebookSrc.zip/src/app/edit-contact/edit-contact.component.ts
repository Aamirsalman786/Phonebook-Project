import { Component, OnInit } from '@angular/core';
import { phonebook } from 'src/Phonebook';
import { ContactService } from '../contact.service';

@Component({
  selector: 'app-edit-contact',
  templateUrl: './edit-contact.component.html',
  styleUrls: ['./edit-contact.component.css']
})
export class EditContactComponent implements OnInit {

  cont:phonebook = new phonebook();

  constructor(private service: ContactService) {
    this.cont.contactName='';
    this.cont.contactNumber='';
   }

  ngOnInit(): void {
  }
  editContact(){
    this.service.editContact(this.cont).subscribe(data =>{

      })
  }

}
