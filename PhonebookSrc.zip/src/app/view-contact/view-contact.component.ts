import { Component, OnInit } from '@angular/core';
import { phonebook } from 'src/Phonebook';
import { ContactService } from '../contact.service';

// @Component({
//   selector: 'app-view-contact',
//   templateUrl: './view-contact.component.html',
//   styleUrls: ['./view-contact.component.css']
// })
// export class ViewContactComponent implements OnInit  {
//   // contactName: string;
//   // cont: phonebook = new phonebook();
//   constructor(private service: ContactService) { }
  
//   firststcontact:ContactService[];
//   nametosearch: string;

  // fetchName(){
  //   this.service.fetchContact(this.contactName).subscribe(data=>{
  //     alert(JSON.stringify(data));
  
 

  //   ngOnInit(){
  //     this.service.fetchContact()
  //       .subscribe
  //       (
  //         data=>{
  //           this.firstcontact = data;
  //         }
  //       )
      
  //   }
  // }  


